
______________________________________________

DAY 01, 02, 03
______________________________________________

	ASSIGNMENT A1: Reading, Reasoing Assingments
		Read, Understand and Practice Codes In Following Books

		Reference: Clean Code, Robert C Martin
			Full Books
		Good Code Bad Code, Tom Long
			Full Books
		Design Patterns, Refactoring Guru
			https://refactoring.guru/design-patterns/composite

	ASSIGNMENT A2: Reading and Practice Assignment
		Read and Practice Code Examples From Following Chapters
			Chapter 10: Better Structures
			Chatper 11: Object Oriented Programming In C
	
			Reference Book: 21st Century C, 2nd Edition

	ASSIGNMENT A2: Reading and Practice Assignment
		Read and Practice Code Examples From Following Chapters
			Chapter 03: Be Principled
			Chatper 07: Functional Programmingss

			[BAD BAD BAD BOOK]
				C++20	Sustainable Software Development
				Patterns and Best Practices
				Second Edition
__________________________________________________
__________________________________________________

YOUR FUTURE AND EVOLUTION
__________________________________________________

Learn C++ [ THROUGHLY ]

	Level 00:
		1. Complete Reference C++, Herbt Schildt
			Focuses On Only Syntax

	Level 01:
		1. Thinking In C++, Volume I, 	Bruce Eckel
		2. Thinking In C++, Volume II, 	Bruce Eckel
			Both Books Discussion Code Design
			Anyone 
	
	Level 02:
		1. C++ Programming Language, Bjarne Stratroup
			Good Reference Book
			For 4+ Years Experience
		2. C++ Primer, Lippman

	Level 03:
		1. Effective C++, Scott Mayer
		2. More Effective C++, Scott Mayer
		3. Effective Modern C++

	Level 04:
		4. Modern C++ Design, Andrew
		5. Exceptional C++
		6. More Exceptional C++
		7. C++ Design and Evolution By Stratroup [ OLD BOOK ]
		8. C++ Videos By Bjarne Stratroup

Learn C [ THROUGHLY ]

	Level 01:
		1. The C Programming Langauge, 2nd Edition
				Kernigam and Dennis Rithice
		2. 21st Century C

Learn Java [ THROUGHLY ]

	Level 00:
		1. Complete Reference Java, Herbt Schildt
			Focuses On Only Syntax

	Level 01:
		1. Core Java For Impatient, Cay Hortsman

	Level 02:
		1. Effective Java

Python Programming

	Level 01:
		Programming Python: Powerful Object-Oriented Programming 
		4th Edition by Mark Lutz (Author)

	Level 02:
		Fluent Python

Software/System Design

	Level 01:
		1. Practical Object-Oriented Design: 
			An Agile Primer Using Ruby 2nd Edition by Sandi Metz
		
		2. Data Structures and Program Design in C++ First Edition
			by Robert L. Kruse (Author), Alexander J. Ryba (Author)

	Level 02:
		Agile Software Development, Principles, Patterns and Practices
			Robert Martin

	Level 03:
		Design Patterns: Elements of Reusable Object-Oriented Software 
		1st Edition
			Erich Gamma (Author), Richard Helm (Author), & 3 more

Programming Langauges Design and Principles [ FOUNDATION BOOKS ]

	Level 01:
		Programming Language Pragmatics 5th Edition
		by Michael Scott (Author), Jonathan Aldrich (Author)

	Level 02:
		Structure and Interpretation of Computer Program, MIT
		by Harold Abelson , Gerald Jay Sussman , et al.

	Level 03:
		Types and Programming Langauges, Benjamin Pierce

Coding Principles and Practices

		The Pragmatic Programmer: Your Journey To Mastery,
		 20th Anniversary Edition (2nd Edition) 2nd Edition
			by David Thomas (Author), Andrew Hunt (Author)

__________________________________________________

www.linkedin.com/in/amarjitlife

+91 9980 777 145
amarjitlife@gmail.com

__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
