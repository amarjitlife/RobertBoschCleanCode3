

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int 

fun sum(x: Int, y: Int) : Int { return x + y }
fun sub(x: Int, y: Int) : Int { return x - y }

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int 
fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ): Int {
	return operation(x, y)
}


fun playWithCalculator() {
	val a: Int = 100
	val b: Int = 30
	var result : Int  = 0

	result = calculator( a, b, ::sum )
	println("Result : $result")

	result = calculator( a, b, ::sub )
	println("Result : $result")


	// val something: Int = ::sum
	val something: (Int, Int) -> Int = ::sum
	result = something( 10, 20 );
	println("Result : $result")		

	val somethingAgain: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	println("Value: $somethingAgain")

	val sumLambda: (Int, Int) -> Int = { a: Int, b: Int -> a + b }
	val subLambda: (Int, Int) -> Int = { a: Int, b: Int -> a - b }

	result = calculator( 99 , 100 , sumLambda) 
	println("Result : $result")		

	result = calculator( 99 , 100 , subLambda) 
	println("Result : $result")		

	result = calculator( 10 , 9 , { 
		a: Int, b: Int -> 
		a * b 
	}) 
	
	println("Result : $result")		

	result = calculator( 10 , 9 ) { 
		a: Int, b: Int -> 
		a * b 
	} 

}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	playWithCalculator()
}

