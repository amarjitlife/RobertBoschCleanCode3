
#include <stdio.h>

//______________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void ( *dance )(); // Function Type L () -> ()
} Human;

void doBhangra() { printf("\nDoing Bhangra...."); }
void doHipHop()  { printf("\nDoing Hip Hop...."); }

//______________________________________________

void playWithHuman() {
	// Human gabbar = { 420, "Gabbar Singh" };
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nHuman ID 	: %d", gabbar.id );
	printf("\nHuman Name 	: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nHuman ID 	: %d", basanti.id );
	printf("\nHuman Name 	: %s", basanti.name );
	basanti.dance();
}


//______________________________________________
//______________________________________________

int main() {
	printf("\n\nFunction: playWithHuman" );
	playWithHuman();

	// printf("\n\nFunction: " );
	// printf("\n\nFunction: " );
	// printf("\n\nFunction: " );
	// printf("\n\nFunction: " );
	// printf("\n\nFunction: " );
	return 0;
}


