
//______________________________________________

// DESIGN PRINCIPLE
//		Design Towards Abstract Type Rather Than Type

// Corollary
//		Design Towards Interfaces Rather Than Concrete Classes

// DESIGN PRACTICES
//		Design Towards Interfaces Rather Than Concrete Classes

/// What It Will Do!
interface Superpower {
	void fly();
	void saveWorld();
}

class Spiderman implements Superpower {
	public void fly() { System.out.println("Fly Like Spiderman"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman"); }
}

class Superman implements Superpower {
	public void fly() { System.out.println("Fly Like Superman"); }
	public void saveWorld() { System.out.println("Save World Like Superman"); }
}

class Heman implements Superpower {
	public void fly() { System.out.println("Fly Like Heman"); }
	public void saveWorld() { System.out.println("Save World Like Heman"); }
}

class Wonderwoman implements Superpower {
	public void fly() { System.out.println("Fly Like Wonderwoman"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman"); }
}

//______________________________________________
// Using Mechanism : Inheritance

// class Human {
// class Human extends Spiderman {
// class Human extends Superman {
class Human extends Heman {
	public void fly() 		 { super.fly(); } //{ System.out.println("Fly Like Human"); }
	public void saveWorld() { super.saveWorld(); }  //{ System.out.println("Save World Like Human"); }
}

//______________________________________________
// Using Mechanism : Composition

// class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Heman {

class HumanBetter {
	// Spiderman power = new Spiderman();
	// Superman power = new Superman();
	Wonderwoman power = new Wonderwoman();
	void fly() 		 { power.fly(); } //{ System.out.println("Fly Like Human"); }
	void saveWorld() { power.saveWorld(); }  //{ System.out.println("Save World Like Human"); }
}

//______________________________________________
// Using Mechanism : Composition

class HumanBest {
	// Spiderman power = new Spiderman();
	// Superman power = new Superman();
	// Wonderwoman power = new Wonderwoman();
	public Superpower power = null;
	void fly() 		 { if ( power != null ) power.fly(); } //{ System.out.println("Fly Like Human"); }
	void saveWorld() { if ( power != null ) power.saveWorld(); }  //{ System.out.println("Save World Like Human"); }
}

//______________________________________________


public class Experiments {
	public static void playWithHuman() {
		Spiderman spider = new Spiderman();
		spider.fly();
		spider.saveWorld();

		Human h = new Human();
		h.fly();
		h.saveWorld();
	}

	public static void playWithHumanBetter() {
		HumanBetter hb = new HumanBetter();
		hb.fly();
		hb.saveWorld();
	}

	public static void playWithHumanBest() {
		HumanBest hb = new HumanBest();
		hb.fly();
		hb.saveWorld();

		hb.power = new Spiderman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new Superman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new Heman();
		hb.fly();
		hb.saveWorld();		

		hb.power = new Wonderwoman();
		hb.fly();
		hb.saveWorld();		
	}

	public static void main( String[] args ) {
		System.out.println("Hello World!!!");
		System.out.println("\n\nFunction : playWithHuman");
		playWithHuman();

		System.out.println("\n\nFunction : playWithHumanBetter");
		playWithHumanBetter();

		System.out.println("\n\nFunction : playWithHumanBest");
		playWithHumanBest();

		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");

	}
}


