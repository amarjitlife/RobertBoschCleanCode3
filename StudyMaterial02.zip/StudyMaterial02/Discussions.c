
//______________________________________________
//
// 	DAY 01
//______________________________________________

	Assingments A1: Reading, Reasoing Assingments
		Chapter 01: Clean Code
		Chapter 02: Meaningful Names

		Reference: Clean Code, Robert C Martin
		
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________


Q1. Write Following sum Function In C
	int sum( int x, int y ) 
	

// DESIGN 01
	int sum( int x, int y ) {
		return x + y
	}

//______________________________________________

Q2. Write Following sum Function In C
	It Should Return Valid Artithmatic Integer
	Or
	Print Can't Calculate For Given x And y Values

	int sum( int x, int y ) 


//______________________________________________



#include <limits.h>

typedef struct result_type {
	int value;
	int valid;
} Result;
  

Result  sum(signed int si_a, signed int si_b) {
  // signed int sum;
  Result result;
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
    /* Handle error */
    result.valid = 0
    exit( 1 );
  } else {
	    sum = si_a + si_b;
	    result.value = sum;
	    result.valid = 1
  		return result;
  }
  /* ... */
}


//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________

